Caden Weiner

To run this file
1. Install flask framework and the related libraries through pip3
pip3 install flask
pip install python-dotenv
pip install flask-wtf
pip install flask-sqlalchemy
pip install flask-migrate
pip install email-validator
pip install flask-login
pip install flask-moment
2. To run the code simply use the command "run flask"
Navigate to your local host in the web browser
http://127.0.0.1:5000/
