#Caden Weiner
#This file contains the appropriate error responses
from flask import render_template
from app import app, db

@app.errorhandler(404)
def not_found_error(error): # not found no fixes needed
    return render_template('404error.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback() # removes the change that brokei it
    return render_template('500error.html'), 500