# To run tests on the model
python3 -m unittest tests/test_models.py
# To run tests on the routes